"""AION: time-correct, research-only market memory."""

__version__ = "0.1.0"
