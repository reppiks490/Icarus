# Claude Code entry point

Read `AGENTS.md` and `docs/CURRENT.md` first. They are the shared, versioned instructions for Claude, Codex, and other contributors. Compare the current git state and source repo commits before resuming. Record any work in `docs/CURRENT.md` and an ADR when contracts change.
